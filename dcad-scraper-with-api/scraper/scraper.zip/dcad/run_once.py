# scraper/dcad/run_once_envfix.py
# Same behavior as run_once.py, but explicitly loads .env so DATABASE_URL/PGSSL are picked up.
# Usage:
#   python -m dcad.run_once_envfix 26272500060150000

import os
import sys
import json
import logging
from datetime import datetime
from decimal import Decimal
from typing import Any, Dict

# Load environment from a local .env (DATABASE_URL, PGSSL, etc.)
try:
    from dotenv import load_dotenv  # pip install python-dotenv
    load_dotenv()
except Exception:
    pass

from sqlalchemy import create_engine, text

# ---- DCAD project bits ----
# Synchronous browser + fetchers
from dcad.fetch import browser, get_detail_html, get_history_html, polite_pause
# Parsers for "Main Improvement" (primary) and "Additional Improvements" (secondary/history)
from dcad.parse_detail import parse_detail_html
from dcad.parse_history import parse_history_html
# Upsert into Postgres
from dcad.upsert import upsert_parsed


log = logging.getLogger("dcad.run_once_envfix")


def _json_default(o: Any) -> Any:
    """JSON serializer default that safely handles Decimal (convert to float)."""
    if isinstance(o, Decimal):
        return float(o)
    raise TypeError(f"Object of type {o.__class__.__name__} is not JSON serializable")


def _save_raw_json(account_id: str, tax_year: int, source_url: str, raw_obj: Dict[str, Any]) -> None:
    """Persist a raw snapshot of what we scraped into public.dcad_json_raw."""
    db_url = os.environ.get("DATABASE_URL")
    if not db_url:
        raise RuntimeError("DATABASE_URL is not set")

    payload = json.dumps(raw_obj, default=_json_default)

    engine = create_engine(db_url, future=True)

    sql = text("""            INSERT INTO public.dcad_json_raw (account_id, tax_year, source_url, raw)
        VALUES (:account_id, :tax_year, :source_url, CAST(:raw AS JSONB))
        ON CONFLICT (account_id, tax_year) DO UPDATE
        SET source_url = EXCLUDED.source_url,
            raw        = EXCLUDED.raw,
            fetched_at = now()
    """)

    with engine.begin() as conn:
        conn.execute(sql, {
            "account_id": account_id,
            "tax_year": tax_year,
            "source_url": source_url,
            "raw": payload,
        })


def run_for_account(account_id: str) -> None:
    """Scrape one account and upsert into Postgres."""
    source_url = f"https://www.dallascad.org/Account/{account_id}"

    # 1) Fetch HTML (sync)
    with browser() as page:
        detail_html = get_detail_html(page, account_id)
        polite_pause()
        history_html = get_history_html(page, account_id)

    # 2) Parse
    detail = parse_detail_html(detail_html) if detail_html else {}
    history = parse_history_html(history_html) if history_html else {}

    # Choose a tax_year to label the snapshot. Prefer parsed value; else current year.
    tax_year = None
    for key in ("tax_year", "year", "assessment_year"):
        if key in detail and detail[key]:
            try:
                tax_year = int(detail[key])
                break
            except Exception:
                pass
    if tax_year is None:
        tax_year = datetime.now().year

    # 3) Save raw snapshot (log error but proceed if saving fails)
    snapshot = {
        "account_id": account_id,
        "tax_year": tax_year,
        "source_url": source_url,
        "detail": detail,
        "history": history,
    }
    try:
        _save_raw_json(account_id, tax_year, source_url, snapshot)
    except Exception as e:
        log.error("Saving raw JSON failed for account_id=%s: %s", account_id, e, exc_info=True)

    # 4) Upsert the parsed structures into your normalized tables
    upsert_parsed(account_id, detail, history)
    log.info("Upsert complete for account_id=%s", account_id)


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    if len(sys.argv) < 2:
        print("Usage: python -m dcad.run_once_envfix <ACCOUNT_ID>")
        sys.exit(2)

    account_id = sys.argv[1].strip()
    log.info("Starting run for account_id=%s", account_id)
    run_for_account(account_id)
    log.info("Done upsert for account_id=%s", account_id)


if __name__ == "__main__":
    main()
