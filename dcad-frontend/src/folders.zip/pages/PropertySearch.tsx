// src/pages/PropertySearch.tsx
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { searchProperties, type SearchItem } from "../lib/api";

const DEFAULT_COUNTY_ID = 1;

export default function PropertySearchPage() {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<SearchItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // filters
  const [minYear, setMinYear] = useState<string>("");
  const [hasPool, setHasPool] = useState<boolean | "">("");
  const [minBeds, setMinBeds] = useState<string>("");
  const [minBaths, setMinBaths] = useState<string>("");
  const [storiesMin, setStoriesMin] = useState<string>("");

  const parsedFilters = useMemo(() => {
    return {
      limit: 25,
      minYear: minYear ? Number(minYear) : undefined,
      hasPool: hasPool === "" ? undefined : Boolean(hasPool),
      minBeds: minBeds ? Number(minBeds) : undefined,
      minBaths: minBaths ? Number(minBaths) : undefined,
      storiesMin: storiesMin ? Number(storiesMin) : undefined,
    };
  }, [minYear, hasPool, minBeds, minBaths, storiesMin]);

  async function runSearch() {
    if (!q.trim()) {
      setResults([]);
      return;
    }
    setLoading(true);
    setErr(null);
    try {
      const resp = await searchProperties(DEFAULT_COUNTY_ID, q, parsedFilters);
      setResults(resp.results ?? []);
    } catch (e: any) {
      setErr(String(e?.message || e));
    } finally {
      setLoading(false);
    }
  }

  // optional: auto-search when filters or query change (debounced)
  useEffect(() => {
    const t = setTimeout(runSearch, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, parsedFilters]);

  return (
    <div style={{ padding: 16, display: "grid", gap: 12 }}>
      <h1 style={{ margin: 0 }}>Property Search</h1>

      {/* Query + Filters */}
      <div
        style={{
          display: "grid",
          gap: 8,
          gridTemplateColumns: "1.5fr repeat(6, 1fr) auto",
          alignItems: "end",
        }}
      >
        <Labeled label="Address contains">
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="e.g. DALLAS or 'CANTON ST'"
            className="input"
          />
        </Labeled>

        <Labeled label="Min Year">
          <input
            value={minYear}
            onChange={(e) => setMinYear(e.target.value.replace(/[^\d]/g, ""))}
            placeholder="1980"
            inputMode="numeric"
            className="input"
          />
        </Labeled>

        <Labeled label="Pool">
          <select
            value={hasPool === "" ? "" : hasPool ? "true" : "false"}
            onChange={(e) => {
              const v = e.target.value;
              setHasPool(v === "" ? "" : v === "true");
            }}
            className="input"
          >
            <option value="">Any</option>
            <option value="true">Yes</option>
            <option value="false">No</option>
          </select>
        </Labeled>

        <Labeled label="Min Beds">
          <input
            value={minBeds}
            onChange={(e) => setMinBeds(e.target.value.replace(/[^\d]/g, ""))}
            placeholder="3"
            inputMode="numeric"
            className="input"
          />
        </Labeled>

        <Labeled label="Min Baths">
          <input
            value={minBaths}
            onChange={(e) =>
              setMinBaths(e.target.value.replace(/[^0-9.]/g, ""))
            }
            placeholder="2 or 2.5"
            inputMode="decimal"
            className="input"
          />
        </Labeled>

        <Labeled label="Min Stories">
          <input
            value={storiesMin}
            onChange={(e) =>
              setStoriesMin(e.target.value.replace(/[^0-9.]/g, ""))
            }
            placeholder="1, 1.5, 2"
            inputMode="decimal"
            className="input"
          />
        </Labeled>

        <button onClick={runSearch} className="btn">
          Apply
        </button>
      </div>

      {/* Status */}
      {err && <div style={{ color: "crimson" }}>Error: {err}</div>}
      {loading && <div>Loading…</div>}

      {/* Results */}
      {!loading && !err && (
        <div
          style={{
            display: "grid",
            gap: 8,
            gridTemplateColumns: "repeat(auto-fill, minmax(380px, 1fr))",
          }}
        >
          {results.map((r) => (
            <Link
              key={`${r.county_id}-${r.account_id}`}
              to={`/property/${r.county_id}/${r.account_id}`}
              style={{
                textDecoration: "none",
                color: "inherit",
                border: "1px solid #e5e7eb",
                borderRadius: 12,
                padding: 12,
                display: "grid",
                gap: 6,
              }}
            >
              <div style={{ fontWeight: 600 }}>{r.situs_address}</div>
              <div style={{ fontSize: 12, opacity: 0.75 }}>
                Account {r.account_id} · County {r.county_id}
              </div>
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(3, 1fr)",
                  gap: 4,
                  fontSize: 13,
                }}
              >
                <Cell label="Year" value={r.year_built ?? "—"} />
                <Cell label="Stories" value={r.stories_display ?? "—"} />
                <Cell label="Baths" value={r.bath_count_display ?? "—"} />
                <Cell label="Beds" value={r.bedroom_count ?? "—"} />
                <Cell label="Living (sf)" value={r.living_area_sqft ?? "—"} />
                <Cell label="Pool" value={r.pool_display ?? "—"} />
              </div>
            </Link>
          ))}
        </div>
      )}

      {/* Empty state */}
      {!loading && !err && q.trim() && results.length === 0 && (
        <div>No matches.</div>
      )}

      <style>{`
        .input {
          width: 100%;
          padding: 8px 10px;
          border: 1px solid #d1d5db;
          border-radius: 8px;
          outline: none;
        }
        .input:focus { border-color: #6366f1; box-shadow: 0 0 0 2px rgba(99,102,241,.15); }
        .btn {
          padding: 10px 14px;
          border-radius: 10px;
          border: 1px solid #111827;
          background: #111827;
          color: white;
          cursor: pointer;
        }
        .btn:hover { filter: brightness(1.05); }
      `}</style>
    </div>
  );
}

function Labeled({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "grid", gap: 4 }}>
      <span style={{ fontSize: 12, opacity: 0.7 }}>{label}</span>
      {children}
    </label>
  );
}

function Cell({ label, value }: { label: string; value: string | number }) {
  return (
    <div style={{ display: "grid", gap: 2 }}>
      <div style={{ fontSize: 11, opacity: 0.65 }}>{label}</div>
      <div style={{ fontVariantNumeric: "tabular-nums" }}>{String(value)}</div>
    </div>
  );
}
