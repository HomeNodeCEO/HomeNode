// src/lib/api.ts
export type SearchItem = {
  county_id: number;
  account_id: string;
  situs_address: string;
  construction_type_display?: string;
  year_built?: number;
  stories_display?: string;
  bath_count_display?: string;
  living_area_sqft?: number;
  bedroom_count?: number;
  pool_display?: string;
  basement_display?: string;
  has_improvements?: boolean;
};

export type SearchResponse = {
  results: SearchItem[];
  count?: number;
};

export type PropertyDetail = {
  county_id: number;
  account_id: string;
  situs_address: string;
  construction_type_display?: string;
  year_built?: number;
  stories_num?: string;
  stories_display?: string;
  bath_count_num?: string;
  bath_count_display?: string;
  living_area_sqft?: number;
  total_living_area?: number;
  bedroom_count?: number;
  pool_bool?: boolean;
  pool_display?: string;
  basement_bool?: boolean;
  basement_display?: string;
  air_conditioning_display?: string;
  heating_display?: string;
  foundation_display?: string;
  roof_material_display?: string;
  roof_type_display?: string;
  exterior_material_display?: string;
  fence_type_display?: string;
  number_units?: number;
  has_improvements?: boolean;
};

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:4000";

type SearchFilters = {
  limit?: number;
  minYear?: number;
  hasPool?: boolean;
  minBeds?: number;
  minBaths?: number;     // accepts 2, 2.5, etc.
  storiesMin?: number;   // accepts 1, 1.5, 2, etc.
};

export async function searchProperties(
  countyId: number,
  q: string,
  filters: SearchFilters = {}
): Promise<SearchResponse> {
  const params = new URLSearchParams();
  params.set("countyId", String(countyId));
  params.set("q", q.trim());
  if (filters.limit != null) params.set("limit", String(filters.limit));
  if (filters.minYear != null) params.set("minYear", String(filters.minYear));
  if (filters.hasPool != null) params.set("hasPool", String(filters.hasPool));
  if (filters.minBeds != null) params.set("minBeds", String(filters.minBeds));
  if (filters.minBaths != null) params.set("minBaths", String(filters.minBaths));
  if (filters.storiesMin != null) params.set("storiesMin", String(filters.storiesMin));

  const url = `${API_BASE}/api/properties/search?${params.toString()}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Search failed: ${res.status} ${res.statusText}`);
  return (await res.json()) as SearchResponse;
}

export async function fetchPropertyDetail(
  countyId: number | string,
  accountId: string
): Promise<PropertyDetail> {
  const url = `${API_BASE}/api/properties/${countyId}/${encodeURIComponent(accountId)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Detail failed: ${res.status} ${res.statusText}`);
  return (await res.json()) as PropertyDetail;
}

// Back-compat alias
export const fetchProperty = fetchPropertyDetail;
