// src/App.tsx
export default function App() {
  return <div style={{padding:16}}>✅ App is rendering</div>;
}
