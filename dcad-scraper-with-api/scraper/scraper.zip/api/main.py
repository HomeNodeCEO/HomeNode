# scraper/api/main.py
from __future__ import annotations

import asyncio
import inspect
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin, parse_qs, urlparse
from .na_utils import fill_na

import httpx
from bs4 import BeautifulSoup
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Use relative imports so running from the "scraper" package works reliably
from ..utils import normalize_account_id
from ..dcad.parse_detail import parse_detail_html
from ..dcad.history_service import build_history_for_account  # NEW

app = FastAPI(title="DCAD Scraper API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_URL = "https://www.dallascad.org"
ACCOUNT_PATH = "/AcctDetail.aspx?ID={account_id}"
HISTORY_PATH = "/AcctHistory.aspx?ID={account_id}"
EXEMPT_DETAILS_PATH = "/ExemptDetails.aspx?ID={account_id}"
EXEMPT_DETAILS_HISTORY_PATH = "/ExemptDetailHistory.aspx?ID={account_id}"
ADDRESS_SEARCH_PATH = "/SearchAddr.aspx"

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/120.0.0.0 Safari/537.36"
)
TIMEOUT = httpx.Timeout(30.0)


def _clean(s: Optional[str]) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())


def _mkurl(path_tmpl: str, account_id: str) -> str:
    return BASE_URL + path_tmpl.format(account_id=account_id) if "{account_id}" in path_tmpl else BASE_URL + path_tmpl


async def _fetch_text(client: httpx.AsyncClient, url: str) -> str:
    r = await client.get(url, headers={"User-Agent": UA})
    r.raise_for_status()
    try:
        return r.text or r.content.decode(r.encoding or "utf-8", errors="ignore")
    except Exception:
        return r.content.decode("utf-8", errors="ignore")


async def _fetch_all(account_id: str):
    acct_url = _mkurl(ACCOUNT_PATH, account_id)
    hist_url = _mkurl(HISTORY_PATH, account_id)
    exdt_url = _mkurl(EXEMPT_DETAILS_PATH, account_id)
    exdt_hist_url = _mkurl(EXEMPT_DETAILS_HISTORY_PATH, account_id)

    async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as client:
        detail_html, history_html, exdt_html, exdt_hist_html = await asyncio.gather(
            _fetch_text(client, acct_url),
            _fetch_text(client, hist_url),
            _fetch_text(client, exdt_url),
            _fetch_text(client, exdt_hist_url),
        )

    return (
        detail_html,
        history_html,
        exdt_html,
        exdt_hist_html,
        acct_url,
        hist_url,
        exdt_url,
        exdt_hist_url,
    )


def _extract_tokens(html: str) -> dict:
    soup = BeautifulSoup(html, "lxml")
    out = {}
    for name in ("__VIEWSTATE", "__EVENTVALIDATION", "__VIEWSTATEGENERATOR", "__EVENTTARGET", "__EVENTARGUMENT"):
        el = soup.find("input", {"name": name})
        if el and el.get("value") is not None:
            out[name] = el.get("value")
    out.setdefault("__EVENTTARGET", "")
    out.setdefault("__EVENTARGUMENT", "")
    return out


def _parse_results_table(html: str) -> List[Dict[str, str]]:
    soup = BeautifulSoup(html, "lxml")
    table = soup.find(id="SearchResults1_dgResults")

    if not table:
        def looks_like_results(tbl):
            hdr = tbl.find("tr")
            if not hdr:
                return False
            thtxt = _clean(hdr.get_text(" ")).upper()
            return ("PROPERTY ADDRESS" in thtxt and "OWNER" in thtxt) or ("TOTAL VALUE" in thtxt and "TYPE" in thtxt)
        for t in soup.find_all("table"):
            if looks_like_results(t):
                table = t
                break

    rows: List[Dict[str, str]] = []
    if not table:
        return rows

    for tr in table.find_all("tr"):
        tds = tr.find_all("td")
        if len(tds) < 6:
            continue
        a = tds[1].find("a", href=True)
        if not a:
            continue
        href = urljoin(BASE_URL + "/", a.get("href"))
        q = parse_qs(urlparse(href).query)
        acc = (q.get("ID") or q.get("id") or [""])[0].strip()
        rows.append({
            "account_id": acc,
            "address": _clean(a.get_text()),
            "city": _clean(tds[2].get_text()),
            "owner": _clean(tds[3].get_text()),
            "total_value": _clean(tds[4].get_text()),
            "type": _clean(tds[5].get_text()),
            "detail_url": href,
        })
    return rows


def _find_next_postback(html: str) -> Optional[str]:
    soup = BeautifulSoup(html, "lxml")
    for a in soup.select('a[href^="javascript:__doPostBack"]'):
        txt = _clean(a.get_text()).upper()
        if "NEXT" in txt or txt in (">", "»"):
            m = re.search(r"__doPostBack\('([^']+)'", a.get("href", ""))
            if m:
                return m.group(1)
    return None


async def _search_address_paged(client: httpx.AsyncClient, q: str, city: str | None, direction: str | None) -> List[Dict[str, str]]:
    search_url = _mkurl(ADDRESS_SEARCH_PATH, "")
    r0 = await client.get(search_url, headers={"User-Agent": UA})
    r0.raise_for_status()
    tokens = _extract_tokens(r0.text)

    # split optional house number
    house, street = "", q
    m = re.match(r"\s*(\d+)\s+(.+)$", q.strip())
    if m:
        house, street = m.group(1), m.group(2)

    form = {
        "__EVENTTARGET": tokens.get("__EVENTTARGET", ""),
        "__EVENTARGUMENT": tokens.get("__EVENTARGUMENT", ""),
        "__VIEWSTATE": tokens.get("__VIEWSTATE", ""),
        "__VIEWSTATEGENERATOR": tokens.get("__VIEWSTATEGENERATOR", ""),
        "__EVENTVALIDATION": tokens.get("__EVENTVALIDATION", ""),
        "txtAddrNum": house,
        "txtStName": street,
        "listStDir": (direction or ""),
        "listCity": (city or ""),
        "cmdSubmit": "Search",
    }
    r = await client.post(search_url, data=form, headers={"User-Agent": UA, "Referer": search_url})
    r.raise_for_status()

    all_rows: List[Dict[str, str]] = []
    pages = 0
    while True:
        pages += 1
        all_rows.extend(_parse_results_table(r.text))

        if pages >= 200:
            break
        next_target = _find_next_postback(r.text)
        if not next_target:
            break

        tokens = _extract_tokens(r.text)
        post = {
            "__EVENTTARGET": next_target,
            "__EVENTARGUMENT": "",
            "__VIEWSTATE": tokens.get("__VIEWSTATE", ""),
            "__VIEWSTATEGENERATOR": tokens.get("__VIEWSTATEGENERATOR", ""),
            "__EVENTVALIDATION": tokens.get("__EVENTVALIDATION", ""),
        }
        r = await client.post(search_url, data=post, headers={"User-Agent": UA, "Referer": search_url})
        r.raise_for_status()

    # de-dupe by account_id
    seen, uniq = set(), []
    for row in all_rows:
        acc = row.get("account_id")
        if acc and acc not in seen:
            uniq.append(row)
            seen.add(acc)
    return uniq


def _split_history(history_html: str) -> tuple[str, str, str]:
    soup = BeautifulSoup(history_html, "lxml")

    def section_html(rx: str) -> Optional[str]:
        for sp in soup.find_all("span", class_="DtlSectionHdr"):
            txt = _clean(sp.get_text()).upper()
            if re.search(rx, txt, re.I):
                frags: List[str] = []
                for sib in sp.next_siblings:
                    if getattr(sib, "name", None) == "span" and "DtlSectionHdr" in (sib.get("class") or []):
                        break
                    frags.append(str(sib))
                return f"<div>{''.join(frags)}</div>"
        return None

    owner = section_html(r"OWNER\s*HISTORY") or history_html
    market = section_html(r"MARKET\s*VALUE\s*HISTORY") or history_html
    taxable = section_html(r"TAXABLE\s*VALUE\s*HISTORY") or history_html
    return owner, market, taxable


def _parse_exempt_detail_history_latest(html: str) -> dict | None:
    soup = BeautifulSoup(html, "lxml")
    hdr = soup.find("span", class_="DtlSectionHdr")
    if not hdr:
        return None

    year_txt = _clean(hdr.get_text())
    table = None
    for el in hdr.next_elements:
        if getattr(el, "name", None) == "table":
            table = el
            break
        if getattr(el, "name", None) == "span" and "DtlSectionHdr" in el.get("class", []):
            break

    if not table:
        return {"year": year_txt}

    tds = table.find_all("td", recursive=True)
    if len(tds) < 2:
        return {"year": year_txt}

    left_tbl = tds[0].find("table")
    right_tbl = tds[1].find("table")
    if not left_tbl or not right_tbl:
        return {"year": year_txt}

    labels = [_clean(x.get_text()) for x in left_tbl.find_all(["th", "td"])]
    values = [_clean(x.get_text()) for x in right_tbl.find_all(["td"])]

    out: Dict[str, str] = {}
    for i, lab in enumerate(labels):
        if i >= len(values):
            break
        key = (
            lab.lower()
            .replace(" ", "_")
            .replace("%", "pct")
            .replace("/", "_")
            .replace("-", "_")
            .replace("__", "_")
            .strip("_")
        )
        if key:
            out[key] = values[i]
    out["year"] = year_txt
    return out or {"year": year_txt}


def _call_parse_detail_html_compat(
    *,
    account_id: str,
    detail_html: str,
    history_owner_html: str,
    history_market_html: str,
    history_taxable_html: str,
    exemption_details_html: str | None = "",
) -> dict:
    """
    Call dcad.parse_detail.parse_detail_html in a signature-agnostic way.

    We try (in order):
      1) keywords with account_html
      2) keywords with html
      3) keywords with detail_html
      4) positional (detail, owner, market, taxable, [exempt])
      Each attempt optionally includes account_id if supported.
    """
    attempts = []

    # (1) account_html with/without account_id
    attempts.append(
        dict(
            kwargs=dict(
                account_id=account_id,
                account_html=detail_html,
                history_owner_html=history_owner_html,
                history_market_html=history_market_html,
                history_taxable_html=history_taxable_html,
                exemption_details_html=(exemption_details_html or ""),
            ),
            positional=None,
        )
    )
    attempts.append(
        dict(
            kwargs=dict(
                account_html=detail_html,
                history_owner_html=history_owner_html,
                history_market_html=history_market_html,
                history_taxable_html=history_taxable_html,
                exemption_details_html=(exemption_details_html or ""),
            ),
            positional=None,
        )
    )

    # (2) html with/without account_id
    attempts.append(
        dict(
            kwargs=dict(
                account_id=account_id,
                html=detail_html,
                history_owner_html=history_owner_html,
                history_market_html=history_market_html,
                history_taxable_html=history_taxable_html,
                exemption_details_html=(exemption_details_html or ""),
            ),
            positional=None,
        )
    )
    attempts.append(
        dict(
            kwargs=dict(
                html=detail_html,
                history_owner_html=history_owner_html,
                history_market_html=history_market_html,
                history_taxable_html=history_taxable_html,
                exemption_details_html=(exemption_details_html or ""),
            ),
            positional=None,
        )
    )

    # (3) detail_html with/without account_id
    attempts.append(
        dict(
            kwargs=dict(
                account_id=account_id,
                detail_html=detail_html,
                history_owner_html=history_owner_html,
                history_market_html=history_market_html,
                history_taxable_html=history_taxable_html,
                exemption_details_html=(exemption_details_html or ""),
            ),
            positional=None,
        )
    )
    attempts.append(
        dict(
            kwargs=dict(
                detail_html=detail_html,
                history_owner_html=history_owner_html,
                history_market_html=history_market_html,
                history_taxable_html=history_taxable_html,
                exemption_details_html=(exemption_details_html or ""),
            ),
            positional=None,
        )
    )

    # (4) positional (oldest style)
    attempts.append(
        dict(
            kwargs=None,
            positional=[
                detail_html,
                history_owner_html,
                history_market_html,
                history_taxable_html,
                (exemption_details_html or ""),
            ],
        )
    )

    last_err: Exception | None = None
    for attempt in attempts:
        try:
            if attempt["kwargs"] is not None:
                return parse_detail_html(**attempt["kwargs"])
            else:
                return parse_detail_html(*attempt["positional"])  # type: ignore[arg-type]
        except TypeError as e:
            last_err = e
            continue
        except ValueError as e:
            # If parser insists on e.g. "account_html (or html) is required", try next style
            last_err = e
            continue
        except Exception as e:
            last_err = e
            break

    raise RuntimeError(f"parse_detail_html() incompatible with provided arguments: {last_err}")

# ---------------------- Pydantic models ----------------------

class DetailResponse(BaseModel):
    account_id: str
    detail: dict

class AddressSearchItem(BaseModel):
    account_id: str
    address: str
    city: str
    owner: str
    total_value: str
    type: str
    detail_url: str

class AddressSearchDetailsItem(BaseModel):
    summary: AddressSearchItem
    detail: dict | None = None
    error: str | None = None

class AddressSearchDetailsResponse(BaseModel):
    query: str
    total: int
    offset: int
    count: int
    results: List[AddressSearchDetailsItem]

# ---------------------- Routes ----------------------

@app.get("/health", include_in_schema=False)
def health():
    return {"ok": True}

@app.get("/detail/{account_id}", response_model=DetailResponse)
async def get_detail(account_id: str):
    try:
        account_id = normalize_account_id(account_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    try:
        (
            detail_html,
            history_html,
            exemption_details_html,
            exemption_details_history_html,
            acct_url,
            hist_url,
            exdt_url,
            exdt_hist_url,
        ) = await _fetch_all(account_id)

        owner_html, market_html, taxable_html = _split_history(history_html)

        parsed = _call_parse_detail_html_compat(
            account_id=account_id,
            detail_html=detail_html,
            history_owner_html=owner_html,
            history_market_html=market_html,
            history_taxable_html=taxable_html,
            exemption_details_html=exemption_details_html or "",
        )

        # helpful URLs if parser doesn't already include them
        parsed.setdefault("history", {}) if isinstance(parsed.get("history"), dict) else parsed.update({"history": {}})
        parsed["history"].setdefault("history_url", hist_url)

        parsed.setdefault("exemption_details", {}) if isinstance(parsed.get("exemption_details"), dict) else parsed.update({"exemption_details": {}})
        parsed["exemption_details"].setdefault("details_url", exdt_url)

        latest = _parse_exempt_detail_history_latest(exemption_details_history_html)
        if latest:
            parsed["exemption_history_latest"] = {**latest, "history_url": exdt_hist_url}
        else:
            parsed.setdefault("exemption_history_latest", {"history_url": exdt_hist_url})

        # NEW: always replace/augment history with robust parser built from the dedicated History page
        try:
            full_history = await build_history_for_account(account_id)
            parsed["history"] = full_history
        except Exception:
            # keep whatever we had; at minimum we set history_url above
            pass

        return DetailResponse(account_id=account_id, detail=parsed)

    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"Fetch failed: {e.request.url}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"failed_to_parse_detail: {e}")

def _row_to_item(row: Dict[str, Any]) -> AddressSearchItem:
    return AddressSearchItem(
        account_id=row.get("account_id", ""),
        address=row.get("address", ""),
        city=row.get("city", ""),
        owner=row.get("owner", ""),
        total_value=row.get("total_value", ""),
        type=row.get("type", ""),
        detail_url=row.get("detail_url", ""),
    )

@app.get("/search/address", response_model=AddressSearchDetailsResponse, response_model_exclude_none=True)
async def address_search(
    q: str = Query(..., description="Street or 'number street' (e.g., 'SNOWMASS' or '1909 SNOWMASS')"),
    city: str | None = Query(None),
    dir: str | None = Query(None, description="Street direction (N, S, E, W)"),
    include_detail: int | bool = Query(0, description="0=summary only, 1=also fetch detail"),
    max_results: int = Query(50, ge=1, le=50, description="Page size (API cap 50)"),
    offset: int = Query(0, ge=0, description="Pagination offset (0, 50, 100, …)"),
):
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as client:
            full_rows = await _search_address_paged(client, q=q, city=city, direction=dir)

        total = len(full_rows)
        page_rows = full_rows[offset : offset + max_results]
        items = [_row_to_item(r) for r in page_rows]

        if not bool(int(include_detail)):
            return AddressSearchDetailsResponse(
                query=q, total=total, offset=offset, count=len(items),
                results=[AddressSearchDetailsItem(summary=it) for it in items],
            )

        sem = asyncio.Semaphore(6)

        async def fetch_detail(it: AddressSearchItem) -> AddressSearchDetailsItem:
            async with sem:
                try:
                    acc = normalize_account_id(it.account_id)
                    (
                        detail_html,
                        history_html,
                        exemption_details_html,
                        exemption_details_history_html,
                        acct_url,
                        hist_url,
                        exdt_url,
                        exdt_hist_url,
                    ) = await _fetch_all(acc)

                    owner_html, market_html, taxable_html = _split_history(history_html)

                    parsed = _call_parse_detail_html_compat(
                        account_id=acc,
                        detail_html=detail_html,
                        history_owner_html=owner_html,
                        history_market_html=market_html,
                        history_taxable_html=taxable_html,
                        exemption_details_html=exemption_details_html or "",
                    )

                    parsed.setdefault("history", {}) if isinstance(parsed.get("history"), dict) else parsed.update({"history": {}})
                    parsed["history"].setdefault("history_url", hist_url)

                    parsed.setdefault("exemption_details", {}) if isinstance(parsed.get("exemption_details"), dict) else parsed.update({"exemption_details": {}})
                    parsed["exemption_details"].setdefault("details_url", exdt_url)

                    latest = _parse_exempt_detail_history_latest(exemption_details_history_html)
                    if latest:
                        parsed["exemption_history_latest"] = {**latest, "history_url": exdt_hist_url}
                    else:
                        parsed.setdefault("exemption_history_latest", {"history_url": exdt_hist_url})

                    # NEW: ensure inline detail also has full history populated
                    try:
                        full_history = await build_history_for_account(acc)
                        parsed["history"] = full_history
                    except Exception:
                        pass

                    return AddressSearchDetailsItem(summary=it, detail=parsed)
                except Exception as e:
                    return AddressSearchDetailsItem(summary=it, error=str(e))

        details = await asyncio.gather(*[fetch_detail(it) for it in items])
        return AddressSearchDetailsResponse(query=q, total=total, offset=offset, count=len(details), results=details)

    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=f"Search failed: {e.request.url}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"address_search_failed: {e}")
