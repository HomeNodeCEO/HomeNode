# scraper/dcad/parse_history.py
from __future__ import annotations

import re
from datetime import datetime
from typing import List, Dict, Any, Optional
from bs4 import BeautifulSoup, Tag

# ----------------------------
# Helpers
# ----------------------------
def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").strip())

def _to_int_safe(s: str) -> Optional[int]:
    try:
        return int(re.sub(r"[^\d]", "", s))
    except Exception:
        return None

def _to_num_safe(s: str) -> Optional[float]:
    s = (s or "").replace(",", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    if not m:
        return None
    try:
        return float(m.group(0))
    except Exception:
        return None

def _parse_date_iso(maybe_date: str) -> Optional[str]:
    if not maybe_date:
        return None
    s = maybe_date.strip()
    # Common DCAD formats like 7/7/1988
    m = re.match(r"^\s*(\d{1,2})/(\d{1,2})/(\d{2,4})\s*$", s)
    if m:
        mm, dd, yyyy = m.groups()
        yyyy = str(yyyy)
        if len(yyyy) == 2:
            yyyy = "20" + yyyy  # naive fallback
        try:
            from datetime import date
            d = date(int(yyyy), int(mm), int(dd)).isoformat()
            if d == "1900-01-01":
                return None
            return d
        except Exception:
            return None
    for fmt in ("%m/%d/%Y", "%m/%d/%y"):
        try:
            dt = datetime.strptime(s, fmt)
            iso = dt.date().isoformat()
            if iso == "1900-01-01":
                return None
            return iso
        except Exception:
            pass
    return None

# ----------------------------
# Value history (market/taxable)
# (History page table with Year, Land, Improve, Market, Taxable)
# ----------------------------
def parse_value_history_from_soup(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    # Find a table with headers containing Market and (optionally) Taxable
    # Common on DCAD "Account History" page.
    candidate_tables = soup.find_all("table")
    best = None
    for tbl in candidate_tables:
        hdr = tbl.find("tr")
        if not hdr:
            continue
        headers = [ _norm(th.get_text(" ", strip=True)).lower() for th in hdr.find_all(["th","td"]) ]
        if any("market" in h for h in headers) and any("year" in h for h in headers):
            best = tbl
            break
    if not best:
        return []

    rows = best.find_all("tr")[1:]
    out: List[Dict[str, Any]] = []
    for tr in rows:
        tds = tr.find_all("td")
        if len(tds) < 2:
            continue
        vals = [ _norm(td.get_text(" ", strip=True)) for td in tds ]
        year = _to_int_safe(vals[0]) if len(vals) >= 1 else None
        if not year:
            continue

        # Try to map typical columns: [Year, Land, Impr, Market, Taxable]
        land = _to_num_safe(vals[1]) if len(vals) > 1 else None
        impr = _to_num_safe(vals[2]) if len(vals) > 2 else None
        market = _to_num_safe(vals[3]) if len(vals) > 3 else None
        taxable = _to_num_safe(vals[4]) if len(vals) > 4 else None

        out.append({
            "tax_year": year,
            "land_value": land,
            "improvement_value": impr,
            "market_value": market,
            "taxable_value": taxable,
        })

    # newest first
    out.sort(key=lambda r: r["tax_year"], reverse=True)
    return out

# ----------------------------------------------------------------
# Owner / Legal Description history (handles TH + TD + TD triplets)
# ----------------------------------------------------------------
_LEGAL_SPAN_ID_RE = re.compile(r"lblLegal\d+$", re.I)
_SALE_DATE_SPAN_ID_RE = re.compile(r"lblSaleDate$", re.I)
_DATE_LABEL_RE = re.compile(r"deed transfer date", re.I)

def _find_owner_legal_table(soup: BeautifulSoup) -> Optional[Tag]:
    # 1) Preferred wrapper
    pnl = soup.find(id="pnlOwnHist")
    if pnl:
        tbl = pnl.find("table")
        if tbl:
            return tbl
    # 2) Headings like "Owner / Legal Description"
    h = soup.find(lambda t: isinstance(t, Tag) and t.name in ('h2','h3','h4','b','strong')
                  and 'owner' in t.get_text(strip=True).lower()
                  and 'legal' in t.get_text(strip=True).lower())
    if h:
        tbl = h.find_next("table")
        if tbl:
            return tbl
    # 3) Fallback: heading containing 'owner'
    h2 = soup.find(lambda t: isinstance(t, Tag) and t.name in ('h2','h3','h4','b','strong')
                   and 'owner' in t.get_text(strip=True).lower())
    if h2:
        tbl = h2.find_next("table")
        if tbl:
            return tbl
    return None

def parse_owner_legal_history_from_soup(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    table = _find_owner_legal_table(soup)
    if not table:
        return []

    kids: List[Tag] = [c for c in table.children if isinstance(c, Tag)]
    # drop header row if it has "Year"
    if kids and kids[0].name == "tr":
        hdr_text = " ".join([_norm(x.get_text(" ", strip=True)) for x in kids[0].find_all(["th","td"])])
        if re.search(r"\byear\b", hdr_text, re.I):
            kids = kids[1:]

    out: List[Dict[str, Any]] = []
    i = 0
    while i < len(kids):
        node = kids[i]
        # Pattern A: TH + TD + TD
        if node.name == "th":
            year_text = _norm(node.get_text(" ", strip=True))
            if re.fullmatch(r"\d{4}", year_text):
                year = int(year_text)
                owner_td = kids[i+1] if i+1 < len(kids) and kids[i+1].name == "td" else None
                legal_td = kids[i+2] if i+2 < len(kids) and kids[i+2].name == "td" else None

                owner_lines = []
                legal_lines = []
                deed_raw = None
                deed_iso = None

                if owner_td:
                    owner_lines = [s for s in owner_td.get_text("\n", strip=True).split("\n") if s.strip()]

                if legal_td:
                    spans = legal_td.find_all(lambda t: isinstance(t, Tag) and t.name == "span"
                                              and _LEGAL_SPAN_ID_RE.search(t.get("id","")))
                    if spans:
                        for sp in spans:
                            txt = _norm(sp.get_text(" ", strip=True))
                            if txt: legal_lines.append(txt)
                    else:
                        for td in legal_td.find_all("td"):
                            txt = _norm(td.get_text(" ", strip=True))
                            if txt and not re.fullmatch(r"\d+:\s*", txt):
                                legal_lines.append(txt)

                    sale_span = legal_td.find(lambda t: isinstance(t, Tag) and t.name == "span"
                                              and _SALE_DATE_SPAN_ID_RE.search(t.get("id","")))
                    if sale_span:
                        deed_raw = _norm(sale_span.get_text(" ", strip=True))
                    else:
                        for td in legal_td.find_all(["td","th"]):
                            txt = td.get_text(" ", strip=True)
                            if txt and _DATE_LABEL_RE.search(txt):
                                nxt = td.find_next("span")
                                deed_raw = _norm(nxt.get_text(" ", strip=True)) if nxt else None
                                break
                    deed_iso = _parse_date_iso(deed_raw or "")

                out.append({
                    "observed_year": year,
                    "owner_lines": owner_lines,
                    "legal_description_lines": legal_lines,
                    "deed_transfer_date_raw": deed_raw,
                    "deed_transfer_date_iso": deed_iso,
                })
                i += 3
                continue

        # Pattern B: well-formed <tr>
        if node.name == "tr":
            cells = node.find_all(["th","td"], recursive=False)
            if len(cells) >= 3:
                year_text = _norm(cells[0].get_text(" ", strip=True))
                if re.fullmatch(r"\d{4}", year_text):
                    year = int(year_text)
                    owner_td, legal_td = cells[1], cells[2]
                    owner_lines = [s for s in owner_td.get_text("\n", strip=True).split("\n") if s.strip()]
                    legal_lines, deed_raw, deed_iso = [], None, None

                    spans = legal_td.find_all(lambda t: isinstance(t, Tag) and t.name == "span"
                                              and _LEGAL_SPAN_ID_RE.search(t.get("id","")))
                    if spans:
                        for sp in spans:
                            txt = _norm(sp.get_text(" ", strip=True))
                            if txt: legal_lines.append(txt)
                    else:
                        for td in legal_td.find_all("td"):
                            txt = _norm(td.get_text(" ", strip=True))
                            if txt and not re.fullmatch(r"\d+:\s*", txt):
                                legal_lines.append(txt)

                    sale_span = legal_td.find(lambda t: isinstance(t, Tag) and t.name == "span"
                                              and _SALE_DATE_SPAN_ID_RE.search(t.get("id","")))
                    if sale_span:
                        deed_raw = _norm(sale_span.get_text(" ", strip=True))
                        deed_iso = _parse_date_iso(deed_raw)

                    out.append({
                        "observed_year": year,
                        "owner_lines": owner_lines,
                        "legal_description_lines": legal_lines,
                        "deed_transfer_date_raw": deed_raw,
                        "deed_transfer_date_iso": deed_iso,
                    })
        i += 1

    out.sort(key=lambda r: r.get("observed_year", 0), reverse=True)
    return out

# ----------------------------
# Exemptions history (from the Account History page)
# ----------------------------
def parse_exemptions_history_from_soup(soup: BeautifulSoup) -> List[Dict[str, Any]]:
    """
    Looks for a section/table that contains exemption history.
    We accept multiple shapes:
      - a table near a heading containing 'Exemption' (or 'Exemptions')
      - a panel id like pnlExemptHist
    Returns rows with best-effort fields: year + lines[]
    """
    # Preferred wrapper
    pnl = soup.find(id="pnlExemptHist")
    if pnl:
        candidate = pnl.find("table")
        if candidate:
            return _parse_exemption_table(candidate)

    # Try headings
    h = soup.find(lambda t: isinstance(t, Tag) and t.name in ('h2','h3','h4','b','strong')
                  and 'exempt' in t.get_text(strip=True).lower())
    if h:
        tbl = h.find_next("table")
        if tbl:
            return _parse_exemption_table(tbl)

    # Fallback: any table that has a header with 'exempt'
    for tbl in soup.find_all("table"):
        hdr = tbl.find("tr")
        if not hdr: 
            continue
        heads = [ _norm(x.get_text(" ", strip=True)).lower() for x in hdr.find_all(["th","td"]) ]
        if any('exempt' in h for h in heads):
            return _parse_exemption_table(tbl)

    return []

def _parse_exemption_table(tbl: Tag) -> List[Dict[str, Any]]:
    rows = tbl.find_all("tr")[1:]
    out: List[Dict[str, Any]] = []
    for tr in rows:
        cells = [ _norm(td.get_text(" ", strip=True)) for td in tr.find_all("td") ]
        if not cells:
            continue
        year = None
        # first cell is often the year
        if re.fullmatch(r"\d{4}", cells[0]):
            year = int(cells[0])
            rest = cells[1:]
        else:
            rest = cells
        if not any(rest):
            continue
        out.append({
            "tax_year": year,
            "lines": [c for c in rest if c],
        })
    # newest first, unknown years last
    out.sort(key=lambda r: r["tax_year"] or 0, reverse=True)
    return out

# ----------------------------
# Public entry point
# ----------------------------
def parse_history_html(html: str) -> Dict[str, Any]:
    soup = BeautifulSoup(html, "lxml")
    value_hist = parse_value_history_from_soup(soup)
    owner_legal = parse_owner_legal_history_from_soup(soup)
    exemptions = parse_exemptions_history_from_soup(soup)

    # derive market/taxable series for your caller’s expected shape
    market_series = [{"tax_year": r["tax_year"], "market_value": r.get("market_value")} for r in value_hist]
    taxable_series = [{"tax_year": r["tax_year"], "taxable_value": r.get("taxable_value")} for r in value_hist]

    return {
        "value_history": value_hist,                 # detailed
        "owner_history": owner_legal,                # your expected key name
        "market_value": market_series,               # lightweight series
        "taxable_value": taxable_series,             # lightweight series
        "exemptions": exemptions,                    # best-effort per year
    }
