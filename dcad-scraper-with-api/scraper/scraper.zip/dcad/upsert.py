from __future__ import annotations

import os
import logging
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Optional

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker

log = logging.getLogger("dcad.upsert")

# ----------------------------
# Engine/session helpers
# ----------------------------
_ENGINE: Optional[Engine] = None
_Session = None


def get_engine() -> Engine:
    global _ENGINE, _Session
    if _ENGINE is None:
        db_url = os.getenv("DATABASE_URL")
        if not db_url:
            raise RuntimeError("DATABASE_URL is not set")
        _ENGINE = create_engine(db_url, pool_pre_ping=True, future=True)
        _Session = sessionmaker(bind=_ENGINE, autoflush=False, autocommit=False, future=True)
    return _ENGINE


def get_session():
    if _Session is None:
        get_engine()
    return _Session()


# ----------------------------
# Normalization utilities
# ----------------------------

_NULLISH = {None, "", "N/A", "NA", "NONE", "UNASSIGNED", "NULL", "N\\A"}


def _is_nullish(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, str):
        s = v.strip().upper()
        return s in _NULLISH
    return False


def to_text_or_none(v: Any) -> Optional[str]:
    if _is_nullish(v):
        return None
    return str(v).strip()


_TRUE_SET = {"Y", "YES", "TRUE", "T", "1"}
_FALSE_SET = {"N", "NO", "FALSE", "F", "0", "NONE", "UNASSIGNED", ""}


def to_bool_or_none(v: Any) -> Optional[bool]:
    if v is None:
        return None
    if isinstance(v, bool):
        return v
    s = str(v).strip().upper()
    if s in _TRUE_SET:
        return True
    if s in _FALSE_SET:
        return False
    # Unknown token -> None (don’t guess)
    return None


def to_int_or_none(v: Any) -> Optional[int]:
    if _is_nullish(v):
        return None
    try:
        s = str(v).replace(",", "").strip()
        if s == "":
            return None
        return int(float(s))
    except (ValueError, TypeError):
        return None


def to_decimal_or_none(v: Any) -> Optional[Decimal]:
    if _is_nullish(v):
        return None
    try:
        s = str(v).replace(",", "").strip()
        if s == "":
            return None
        return Decimal(s)
    except (InvalidOperation, ValueError, TypeError):
        return None


# ----------------------------
# Upsert parsed payloads
# ----------------------------

def upsert_parsed(account_id: str, detail: Dict[str, Any], history: Dict[str, Any]) -> None:
    """
    Insert/update parsed DCAD data into our DB tables.

    Expected keys (best-effort; missing keys are fine):
      detail["primary_improvements"] -> dict of the "primary improvements"
      (fallbacks: detail["main_improvement"], detail["primary"])
      detail["secondary_improvements"] -> list[dict]
    """
    engine = get_engine()
    with get_session() as s:
        # -------- primary_improvements --------
        primary: Dict[str, Any] = (
            (detail or {}).get("primary_improvements")
            or (detail or {}).get("main_improvement")
            or (detail or {}).get("primary")
            or {}
        )

        # Booleans
        spa = to_bool_or_none(primary.get("spa"))
        pool = to_bool_or_none(primary.get("pool"))
        sauna = to_bool_or_none(primary.get("sauna"))
        basement = to_bool_or_none(primary.get("basement"))
        sprinkler = to_bool_or_none(primary.get("sprinkler"))

        # Numerics
        stories = to_decimal_or_none(primary.get("stories"))
        wetbars = to_int_or_none(primary.get("wetbars"))
        kitchens = to_int_or_none(primary.get("kitchens"))
        county_id = to_int_or_none(primary.get("county_id"))
        actual_age = to_int_or_none(primary.get("actual_age"))
        fireplaces = to_int_or_none(primary.get("fireplaces"))
        year_built = to_int_or_none(primary.get("year_built"))
        depreciation = to_decimal_or_none(primary.get("depreciation"))
        number_units = to_int_or_none(primary.get("number_units"))
        bedroom_count = to_int_or_none(primary.get("bedroom_count"))
        desirability_id = to_int_or_none(primary.get("desirability_id"))
        living_area_sqft = to_int_or_none(primary.get("living_area_sqft"))
        percent_complete = to_decimal_or_none(primary.get("percent_complete"))
        total_living_area = to_int_or_none(primary.get("total_living_area"))
        effective_year_built = to_int_or_none(primary.get("effective_year_built"))
        total_area_sqft = to_int_or_none(primary.get("total_area_sqft"))
        baths_full = to_decimal_or_none(primary.get("baths_full"))
        baths_half = to_decimal_or_none(primary.get("baths_half"))

        # Derive bath_count if provided as full/half
        bath_count = to_decimal_or_none(primary.get("bath_count"))
        if bath_count is None and (baths_full is not None or baths_half is not None):
            f = float(baths_full) if baths_full is not None else 0.0
            h = float(baths_half) if baths_half is not None else 0.0
            bath_count = Decimal(str(f + 0.5 * h))

        # Text-ish
        heating = to_text_or_none(primary.get("heating"))
        roof_type = to_text_or_none(primary.get("roof_type"))
        fence_type = to_text_or_none(primary.get("fence_type"))
        foundation = to_text_or_none(primary.get("foundation"))
        stories_raw = to_text_or_none(primary.get("stories_raw"))
        basement_raw = to_text_or_none(primary.get("basement_raw"))
        desirability = to_text_or_none(primary.get("desirability"))
        roof_material = to_text_or_none(primary.get("roof_material"))
        air_conditioning = to_text_or_none(primary.get("air_conditioning"))
        desirability_raw = to_text_or_none(primary.get("desirability_raw"))
        construction_type = to_text_or_none(primary.get("construction_type"))
        exterior_material = to_text_or_none(primary.get("exterior_material"))

        upsert_pi = text(
            """
            INSERT INTO public.primary_improvements (
              account_id,
              spa, pool, sauna, heating, stories, wetbars, basement, kitchens, county_id,
              roof_type, sprinkler, actual_age, bath_count, fence_type, fireplaces, foundation,
              year_built, stories_raw, basement_raw, depreciation, desirability, number_units,
              bedroom_count, roof_material, desirability_id, air_conditioning, desirability_raw,
              living_area_sqft, percent_complete, construction_type, exterior_material,
              total_living_area, effective_year_built, baths_full, baths_half, total_area_sqft, updated_at
            )
            VALUES (
              :account_id,
              :spa, :pool, :sauna, :heating, :stories, :wetbars, :basement, :kitchens, :county_id,
              :roof_type, :sprinkler, :actual_age, :bath_count, :fence_type, :fireplaces, :foundation,
              :year_built, :stories_raw, :basement_raw, :depreciation, :desirability, :number_units,
              :bedroom_count, :roof_material, :desirability_id, :air_conditioning, :desirability_raw,
              :living_area_sqft, :percent_complete, :construction_type, :exterior_material,
              :total_living_area, :effective_year_built, :baths_full, :baths_half, :total_area_sqft, now()
            )
            ON CONFLICT (account_id) DO UPDATE SET
              spa = EXCLUDED.spa,
              pool = EXCLUDED.pool,
              sauna = EXCLUDED.sauna,
              heating = EXCLUDED.heating,
              stories = EXCLUDED.stories,
              wetbars = EXCLUDED.wetbars,
              basement = EXCLUDED.basement,
              kitchens = EXCLUDED.kitchens,
              county_id = EXCLUDED.county_id,
              roof_type = EXCLUDED.roof_type,
              sprinkler = EXCLUDED.sprinkler,
              actual_age = EXCLUDED.actual_age,
              bath_count = EXCLUDED.bath_count,
              fence_type = EXCLUDED.fence_type,
              fireplaces = EXCLUDED.fireplaces,
              foundation = EXCLUDED.foundation,
              year_built = EXCLUDED.year_built,
              stories_raw = EXCLUDED.stories_raw,
              basement_raw = EXCLUDED.basement_raw,
              depreciation = EXCLUDED.depreciation,
              desirability = EXCLUDED.desirability,
              number_units = EXCLUDED.number_units,
              bedroom_count = EXCLUDED.bedroom_count,
              roof_material = EXCLUDED.roof_material,
              desirability_id = EXCLUDED.desirability_id,
              air_conditioning = EXCLUDED.air_conditioning,
              desirability_raw = EXCLUDED.desirability_raw,
              living_area_sqft = EXCLUDED.living_area_sqft,
              percent_complete = EXCLUDED.percent_complete,
              construction_type = EXCLUDED.construction_type,
              exterior_material = EXCLUDED.exterior_material,
              total_living_area = EXCLUDED.total_living_area,
              effective_year_built = EXCLUDED.effective_year_built,
              baths_full = EXCLUDED.baths_full,
              baths_half = EXCLUDED.baths_half,
              total_area_sqft = EXCLUDED.total_area_sqft,
              updated_at = now()
            """
        )

        s.execute(
            upsert_pi,
            {
                "account_id": account_id,
                "spa": spa,
                "pool": pool,
                "sauna": sauna,
                "heating": heating,
                "stories": stories,
                "wetbars": wetbars,
                "basement": basement,
                "kitchens": kitchens,
                "county_id": county_id,
                "roof_type": roof_type,
                "sprinkler": sprinkler,
                "actual_age": actual_age,
                "bath_count": bath_count,
                "fence_type": fence_type,
                "fireplaces": fireplaces,
                "foundation": foundation,
                "year_built": year_built,
                "stories_raw": stories_raw,
                "basement_raw": basement_raw,
                "depreciation": depreciation,
                "desirability": desirability,
                "number_units": number_units,
                "bedroom_count": bedroom_count,
                "roof_material": roof_material,
                "desirability_id": desirability_id,
                "air_conditioning": air_conditioning,
                "desirability_raw": desirability_raw,
                "living_area_sqft": living_area_sqft,
                "percent_complete": percent_complete,
                "construction_type": construction_type,
                "exterior_material": exterior_material,
                "total_living_area": total_living_area,
                "effective_year_built": effective_year_built,
                "baths_full": baths_full,
                "baths_half": baths_half,
                "total_area_sqft": total_area_sqft,
            },
        )

        # -------- secondary_improvements --------
        # Expect a list of dicts with fields like:
        # imp_num, imp_type, imp_desc, year_built, construction, floor_type, ext_wall,
        # num_stories, area_size, value, depreciation
        sec_list = (detail or {}).get("secondary_improvements") or []
        # Delete-and-reinsert pattern per account (keeps it simple and idempotent)
        s.execute(
            text("DELETE FROM public.secondary_improvements WHERE account_id = :account_id"),
            {"account_id": account_id},
        )
        if sec_list:
            ins_sec = text(
                """
                INSERT INTO public.secondary_improvements (
                  account_id, imp_num, imp_type, imp_desc, year_built,
                  construction, floor_type, ext_wall, num_stories,
                  area_size, value, depreciation
                )
                VALUES (
                  :account_id, :imp_num, :imp_type, :imp_desc, :year_built,
                  :construction, :floor_type, :ext_wall, :num_stories,
                  :area_size, :value, :depreciation
                )
                """
            )
            for row in sec_list:
                # Skip rows that don't have imp_num; DB requires NOT NULL
                imp_num = to_int_or_none(row.get("imp_num"))
                if imp_num is None:
                    continue
                s.execute(
                    ins_sec,
                    {
                        "account_id": account_id,
                        "imp_num": imp_num,
                        "imp_type": to_text_or_none(row.get("imp_type")),
                        "imp_desc": to_text_or_none(row.get("imp_desc")),
                        "year_built": to_int_or_none(row.get("year_built")),
                        "construction": to_text_or_none(row.get("construction")),
                        "floor_type": to_text_or_none(row.get("floor_type")),
                        "ext_wall": to_text_or_none(row.get("ext_wall")),
                        "num_stories": to_int_or_none(row.get("num_stories")),
                        "area_size": to_int_or_none(row.get("area_size")),
                        "value": to_decimal_or_none(row.get("value")),
                        "depreciation": to_decimal_or_none(row.get("depreciation")),
                    },
                )

        s.commit()
        log.info("Upsert complete for account_id=%s", account_id)
