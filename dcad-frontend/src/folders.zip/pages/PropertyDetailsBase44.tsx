import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { fetchDetail } from "@/lib/dcad";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  ArrowLeft, Upload, ChevronLeft, ChevronRight,
  DollarSign, Landmark, TrendingDown, Building, MapPin,
  Home, BedDouble, Bath, Car, Zap, AlertTriangle, Percent, FileDown
} from "lucide-react";

// Display helper: shows fallback until value exists
function Bind({ value, fallback, format }: { value: any; fallback?: any; format?: (v: any) => any }) {
  const has = value !== undefined && value !== null && value !== "";
  const out = has ? (format ? format(value) : value) : fallback;
  return <span>{out}</span>;
}

type Property = {
  account_number?: string;
  address?: string;
  photos?: string[];

  // values
  market_value?: number | "";
  appraised_value?: number | "";
  improvement_value?: number | "";
  land_value?: number | "";
  neighborhood_multiplier?: number | "";
  county?: string;
  neighborhood_code?: string;
  subdivision?: string;

  // details
  square_footage?: number | "";
  land_acreage?: number | "";
  bedroom_count?: number | "";
  bath_count?: number | "";
  garage_bay_count?: number | "";
  solar_panels?: boolean;
  functional_obsolescence?: boolean;

  // county details
  classification?: string;
  year_built?: number | "";
  effective_year_built?: number | "";
  last_inspection_year?: number | "";

  // protest history (optional)
  protest_history?: Array<{ year: number; status: string; initial_value: number; final_value: number }>;
};

export default function PropertyDetailsBase44() {
  const location = useLocation();
  const presetAccount = useMemo(() => new URLSearchParams(location.search).get("account_id") || "", [location.search]);

  const [property, setProperty] = useState<Property>({
    account_number: presetAccount,
    photos: [],
  });
  const [loading, setLoading] = useState(false);
  const [raw, setRaw] = useState<any>(null);
  const hasAutoImported = useRef(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  function toNum(v: any): number | "" {
    if (v === null || v === undefined || v === "") return "";
    const n = Number(String(v).replace(/[,$\s]/g, ""));
    return Number.isFinite(n) ? n : "";
  }

  // TODO: Update these paths to your actual API JSON (use the raw JSON panel below)
  function mapDetailToProperty(detail: any): Partial<Property> {
    return {
      address: detail?.summary?.address ?? detail?.address ?? "",
      photos: detail?.photos ?? [],

      market_value: toNum(detail?.current_year?.market_value),
      appraised_value: toNum(detail?.current_year?.taxable_value),
      improvement_value: toNum(detail?.value_summary?.improvement_value ?? detail?.improvements?.improvement_value),
      land_value: toNum(detail?.value_summary?.land_value ?? detail?.improvements?.land_value),
      neighborhood_multiplier: toNum(detail?.neighborhood?.multiplier),

      county: detail?.summary?.county ?? detail?.county ?? "",

      square_footage: toNum(detail?.characteristics?.living_area_sqft),
      land_acreage: toNum(detail?.land?.acreage),
      bedroom_count: toNum(detail?.characteristics?.bedrooms),
      bath_count: toNum(detail?.characteristics?.baths),
      garage_bay_count: toNum(detail?.characteristics?.garage_bays),
      solar_panels: !!detail?.features?.solar_panels,
      functional_obsolescence: !!detail?.condition?.functional_obsolescence,

      classification: detail?.classification ?? "",
      year_built: toNum(detail?.characteristics?.year_built),
      effective_year_built: toNum(detail?.characteristics?.effective_year_built),
      last_inspection_year: toNum(detail?.inspection?.last_year),

      neighborhood_code: detail?.neighborhood?.code ?? "",
      subdivision: detail?.neighborhood?.subdivision ?? "",

      protest_history: detail?.protest_history ?? [],
    };
  }

  async function importFromDCAD() {
    if (!property.account_number) { alert("Enter an Account ID first."); return; }
    setLoading(true);
    try {
      const resp = await fetchDetail(property.account_number);
      setRaw(resp);
      const mapped = mapDetailToProperty(resp?.detail);
      setProperty(prev => ({ ...prev, ...mapped }));
    } catch (e: any) {
      console.error(e);
      alert(e?.message || "Import failed");
    } finally { setLoading(false); }
  }

  useEffect(() => {
    if (!hasAutoImported.current && property.account_number) {
      hasAutoImported.current = true;
      importFromDCAD();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [property.account_number]);

  const capLoss = (property.market_value || 0) - (property.appraised_value || 0);

  const nextImage = () => {
    if ((property.photos?.length || 0) > 1) {
      setCurrentImageIndex((i) => (i + 1) % (property.photos as string[]).length);
    }
  };
  const prevImage = () => {
    if ((property.photos?.length || 0) > 1) {
      setCurrentImageIndex((i) => (i - 1 + (property.photos as string[]).length) % (property.photos as string[]).length);
    }
  };

  const formatBathCount = (count: any) => {
    if (count === undefined || count === null || count === "") return "N/A";
    const n = Number(count);
    const full = Math.floor(n);
    const half = Math.round((n % 1) * 10);
    return half > 0 ? `${full} Full, ${half} Half` : `${full} Full`;
  };

  return (
    <div className="bg-slate-50 min-h-screen p-4 sm:p-6 lg:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Top bar + Import */}
        <div className="flex items-center justify-between">
          <Link to="/" className="text-sm underline"><ArrowLeft className="w-4 h-4 inline -mt-1 mr-1" />Back</Link>
          <h1 className="text-3xl font-bold text-slate-900">Property Report</h1>
          <div />
        </div>

        <Card>
          <CardHeader className="grid gap-3 sm:grid-cols-[160px_1fr_auto] items-center">
            <label className="text-sm font-medium text-slate-700">Account ID</label>
            <Input
              placeholder="Enter DCAD Account ID"
              value={property.account_number || ""}
              onChange={(e) => setProperty(p => ({ ...p, account_number: e.target.value }))}
            />
            <Button onClick={importFromDCAD} disabled={loading || !property.account_number}>
              {loading ? "Importing..." : "Import"}
            </Button>
          </CardHeader>
        </Card>

        {/* Hero card with photo + address + actions (mirrors Base44 layout) */}
        <Card className="overflow-hidden shadow-lg">
          <CardHeader className="p-0 relative">
            <img
              src={(property.photos && property.photos[currentImageIndex]) || "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?q=80&w=1974&auto=format&fit=crop"}
              alt="Property"
              className="w-full h-60 object-cover"
            />
            {(property.photos?.length || 0) > 1 && (
              <>
                <Button size="icon" variant="secondary" className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full" onClick={prevImage}><ChevronLeft/></Button>
                <Button size="icon" variant="secondary" className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full" onClick={nextImage}><ChevronRight/></Button>
              </>
            )}
            <Button size="sm" variant="secondary" className="absolute top-2 right-2 bg-gray-900/50 text-white hover:bg-gray-900/70">
              <Upload className="w-4 h-4 mr-2"/>
              Upload Photos
            </Button>
          </CardHeader>

          <div className="p-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-3xl font-bold text-slate-900">
                  <Bind value={property.address} fallback="123 Main St, Dallas, TX 75201" />
                </h2>
                {/* jurisdiction chips (static examples; you can wire your tax modal later) */}
                <div className="flex items-center gap-2 mt-2 flex-wrap">
                  <Button variant="outline" size="sm" className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                    <Bind value={property.county} fallback="Dallas" /> County
                  </Button>
                  <Button variant="outline" size="sm" className="bg-blue-100 text-blue-800 hover:bg-blue-200">Dallas ISD</Button>
                  <Button variant="outline" size="sm" className="bg-blue-100 text-blue-800 hover:bg-blue-200">City of Dallas</Button>
                  <Button variant="outline" size="sm" className="bg-blue-100 text-blue-800 hover:bg-blue-200">Parkland Hospital</Button>
                </div>
              </div>
              <div className="flex gap-2">
                <Button className="bg-blue-600 hover:bg-blue-700">Change Log</Button>
                <Button className="bg-red-600 hover:bg-red-700">
                  <FileDown className="w-4 h-4 mr-2"/>
                  Generate PDF
                </Button>
              </div>
            </div>
          </div>

          {/* Stat cards */}
          <CardContent className="p-6 pt-0 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <StatCard icon={<DollarSign className="w-6 h-6 text-green-600" />} label="Market Value"
              value={`$${(property.market_value as number | undefined)?.toLocaleString?.() || "N/A"}`} />
            <StatCard icon={<Landmark className="w-6 h-6 text-blue-600" />} label="Assessed Value"
              value={`$${(property.appraised_value as number | undefined)?.toLocaleString?.() || "N/A"}`} />
            <StatCard icon={<TrendingDown className="w-6 h-6 text-red-600" />} label="Cap Loss"
              value={`$${capLoss.toLocaleString()}`} />
            <StatCard icon={<Building className="w-6 h-6 text-purple-600" />} label="Improvement Value"
              value={`$${(property.improvement_value as number | undefined)?.toLocaleString?.() || "N/A"}`} />
            <StatCard icon={<MapPin className="w-6 h-6 text-orange-600" />} label="Land Value"
              value={`$${(property.land_value as number | undefined)?.toLocaleString?.() || "N/A"}`} />
            <StatCard icon={<Percent className="w-6 h-6 text-indigo-600" />} label="NBHD Multiplier"
              value={<Bind value={property.neighborhood_multiplier} fallback="—" />} />
          </CardContent>
        </Card>

        {/* Two-column sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <SectionCard title="Property Details">
            <div className="space-y-3">
              <KeyVal icon={<Home className="w-4 h-4 text-slate-500"/>} label="Square Footage">
                <Bind value={property.square_footage} fallback="2,184" /> sq ft
              </KeyVal>
              <KeyVal icon={<MapPin className="w-4 h-4 text-slate-500"/>} label="Land Size">
                <Bind value={property.land_acreage} fallback="0.25" /> acres
              </KeyVal>
              <KeyVal icon={<BedDouble className="w-4 h-4 text-slate-500"/>} label="Bedroom Count">
                <Bind value={property.bedroom_count} fallback="3" />
              </KeyVal>
              <KeyVal icon={<Bath className="w-4 h-4 text-slate-500"/>} label="Bath Count">
                <Bind value={property.bath_count} fallback="2.5" format={formatBathCount} />
              </KeyVal>
              <KeyVal icon={<Car className="w-4 h-4 text-slate-500"/>} label="Garage Bay Count">
                <Bind value={property.garage_bay_count} fallback="2" />
              </KeyVal>
              <KeyVal icon={<Zap className="w-4 h-4 text-slate-500"/>} label="Solar Panels">
                <Badge variant={(property.solar_panels ? "default" : "secondary") as any}>
                  {property.solar_panels ? "Yes" : "No"}
                </Badge>
              </KeyVal>
              <KeyVal icon={<AlertTriangle className="w-4 h-4 text-slate-500"/>} label="Functional Obsolescence">
                <Badge variant={(property.functional_obsolescence ? "destructive" : "secondary") as any}>
                  {property.functional_obsolescence ? "Yes" : "No"}
                </Badge>
              </KeyVal>
            </div>
          </SectionCard>

          <SectionCard title="County Details">
            <div className="space-y-3">
              <PlainKV label="Classification"><Bind value={property.classification} fallback="Residential" /></PlainKV>
              <PlainKV label="Actual Year Built"><Bind value={property.year_built} fallback="1985" /></PlainKV>
              <PlainKV label="Effective Year Built"><Bind value={property.effective_year_built} fallback="1995" /></PlainKV>
              <PlainKV label="Last Inspection"><Bind value={property.last_inspection_year} fallback="2023" /></PlainKV>
              <PlainKV label="Neighborhood Code"><Bind value={property.neighborhood_code} fallback="DAL-012A" /></PlainKV>
              <PlainKV label="Subdivision"><Bind value={property.subdivision} fallback="Downtown Historic District" /></PlainKV>
            </div>
          </SectionCard>

          <SectionCard title="Adjustments">
            <div className="space-y-3">
              <PlainKV label="Account Adjustment"><Bind value={(property as any).account_adjustments} fallback="0" /></PlainKV>
              <hr />
              <PlainKV label="Improvement Adj. 1"><Bind value={(property as any).improvement_adjustment_1} fallback="0" /></PlainKV>
              <PlainKV label="Improvement Adj. 2"><Bind value={(property as any).improvement_adjustment_2} fallback="0" /></PlainKV>
              <PlainKV label="Improvement Adj. 3"><Bind value={(property as any).improvement_adjustment_3} fallback="0" /></PlainKV>
              <hr />
              <PlainKV label="Land Adj. 1"><Bind value={(property as any).land_adjustment_1} fallback="0" /></PlainKV>
              <PlainKV label="Land Adj. 2"><Bind value={(property as any).land_adjustment_2} fallback="0" /></PlainKV>
              <PlainKV label="Land Adj. 3"><Bind value={(property as any).land_adjustment_3} fallback="0" /></PlainKV>
            </div>
          </SectionCard>

          <SectionCard title="Secondary Improvements">
            <div>
              {(property as any).secondary_improvements?.length ? (
                <ol className="list-decimal list-inside space-y-1">
                  {(property as any).secondary_improvements.map((item: string, i: number) => <li key={i}>{item}</li>)}
                </ol>
              ) : (
                <p className="text-slate-500">No secondary improvements listed.</p>
              )}
            </div>
          </SectionCard>
        </div>

        {/* Protest history table */}
        <SectionCard title="Protest History">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Year</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Initial Value</TableHead>
                <TableHead>Final Value</TableHead>
                <TableHead>Change</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {property.protest_history?.length ? (
                property.protest_history.map((row, i) => (
                  <TableRow key={i}>
                    <TableCell>{row.year}</TableCell>
                    <TableCell><Badge variant={row.status === "Completed" ? "default" : "secondary"}>{row.status}</Badge></TableCell>
                    <TableCell>${row.initial_value.toLocaleString()}</TableCell>
                    <TableCell>${row.final_value.toLocaleString()}</TableCell>
                    <TableCell className={row.final_value < row.initial_value ? "text-green-600" : "text-slate-500"}>
                      ${(row.final_value - row.initial_value).toLocaleString()}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={5} className="text-center">No protest history available.</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </SectionCard>

        {/* Raw JSON while wiring */}
        <details className="mt-2">
          <summary className="cursor-pointer">Show raw API JSON</summary>
          <pre className="whitespace-pre-wrap bg-slate-50 p-3 rounded-md text-sm">
{JSON.stringify(raw, null, 2)}
          </pre>
        </details>
      </div>
    </div>
  );
}

/* --- small helpers mirrored from your structure --- */
function StatCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 p-4 bg-slate-100/80 rounded-lg justify-between">
      <div className="flex items-center gap-4">
        <div className="bg-slate-200 p-3 rounded-lg">{icon}</div>
        <div>
          <p className="text-sm text-slate-600">{label}</p>
          <p className="font-bold text-slate-900 text-xl">{value}</p>
        </div>
      </div>
    </div>
  );
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card className="shadow-lg">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle>{title}</CardTitle>
        <Button size="sm" variant="outline">Edit</Button>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function KeyVal({ icon, label, children }: { icon?: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="flex justify-between items-center">
      <span className="flex items-center gap-2">{icon}{label}:</span>
      <span className="font-medium">{children}</span>
    </div>
  );
}

function PlainKV({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex justify-between items-center text-sm">
      <span>{label}:</span>
      <span className="font-medium">{children}</span>
    </div>
  );
}
